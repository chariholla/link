//
//  CelebrusUtils.h
//  CelebrusAppleCSA
//
//  Created by administrator on 10/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusUtils_h
#define CelebrusAppleCSA_CelebrusUtils_h

#import <UIKit/UIKit.h>
#import "CelebrusIntegrationService.h"
#import "CelebrusControlType.h"
#import "CelebrusSelectedItem.h"
#import "CelebrusContentPlacement.h"
#import "CelebrusOrientationType.h"
#import "CelebrusConsentType.h"

@interface CelebrusUtils : NSObject

+(void) setIntegrationService: (CelebrusIntegrationService *) integrationService;
+(CelebrusIntegrationService *) integrationService;
+(NSString *) createCookieWithCsaName: (NSString*) csaName
                                  uvt: (NSString*) uvt
                              consent: (CelebrusConsentType*) consent;
+(int) utcTimeZoneOffsetMinutes;
+(NSString *) generatePlatformString;
+(long long) currentTimeMillis;
+(NSString *) currentTimeMillisAsString;
+(long long) timestampForDate: (NSDate *) date;
+(NSString *) boolString: (BOOL) value;
+(NSString *) doubleString: (double) value;
+(NSString *) floatString: (float) value;
+(NSString *) intString: (int) value;
+(NSString *) longString: (long) value;
+(NSString *) longLongString: (long long) value;
+(NSString *) escapeSemicolons: (NSString *) val;
+(NSString *) nameForView: (UIView *) view;
+(NSString *) identifierForView: (UIView *) view;
+(int) selectedIndexForView: (UIView *) view;
+(void) notImplemented;
+(void) sleep: (unsigned long) milliseconds;
+(id) nullSafeJsonValue: (id) value;
+(id) jsonFromString: (NSString *) value;

/**
 * Convenience method which calls {@link #integrationService()
 * #getValue(View)}
 */
+(NSString *) valueForView: (UIView *) view;
/**
 * Convenience method which calls {@link #integrationService()
 * #getFormName(View)}
 */
+(NSString *) formNameForView: (UIView *) view;
/**
 * Convenience method which calls {@link #integrationService()
 * #getFormIdentifier(View)}
 */
+(NSString *) formIdentifierForView: (UIView *) view;
/**
 * Convenience method which calls {@link #integrationService()
 * #getControlType(View)}
 */
+(CelebrusControlType *) controlTypeForView: (UIView *) view;

+(NSString *) valueForTableView:(UITableView *) tableView
                   forIndexPath:(NSIndexPath *) indexPath;

+(int) selectedIndexForTableView:(UITableView *) tableView
                    forIndexPath:(NSIndexPath *) path;

+(NSString*) stringFromJson: (NSArray<NSDictionary*>*) json;

+(NSArray<CelebrusSelectedItem *> *) selectedItemsForTableAfterTap:(UITableView *) tableView
                                               tappedCellIndexPath:(NSIndexPath *) tappedCellPath;
/**
 * A delimeter used for variable argument paramters where <code>nils</code> are naturally permitted within the argument list.
 */
+(id) varArgsEndDelimeter;

+(NSString *) validateCollectionUrl: (NSString *)incomingCollectionUrl;

+(NSArray *) getDomains: (NSString *) domains;

+(NSArray *) getUvtNameAndValue: (NSString *) uvt;

+(void) shareDeviceIdWithWebViewDomains: (NSArray *) domains withUvt: (NSString *) uvt;

+(void) showSessionIdentificationAlert: (long long) currentSessionNumber withSessionKey: (NSString *) currentSessionKey;

+(NSDictionary*) createContentLoadingJsonEvent: (NSString*) contentName
                                     isEnabled: (bool) isEnabled
                                  contentHints: (NSString*) contentHints
                              interactionPoint: (NSString*) contentInteractionPoint
                               contentLanguage: (NSString*) contentLanguage
                                    placements: (NSArray<CelebrusContentPlacement*>*) placements;

+(NSString*) toJsonString: (NSArray<CelebrusContentPlacement*>*) placements;

+(bool) isEqual: (NSString*) one
             to: (NSString*) two;

+(bool) isSameClassInstance: (id) one
                         to: (id) two;

+(CelebrusOrientationType*) applicationOrientation:(UIInterfaceOrientation) currentOrientation;

+(CelebrusOrientationType*) deviceOrientation:(UIDeviceOrientation) currentOrientation;

+(BOOL) deviceOrientationIsReversed:(UIDeviceOrientation) currentOrientation;

+(NSString *) selectedItemIndicesAsString: (NSArray<CelebrusSelectedItem*> *) selectedItems;

+(NSString *) selectedItemValuesAsString: (NSArray<CelebrusSelectedItem*>*) selectedItems
                          forConfigFlags: (long long) configFlags;

+(NSString *)cookieValueWithCookieName: (NSString *) name
                               cookies: (NSString *) cookies;

+(NSString *) domainForUrl: (NSString *) tgtUrl;

@end

#endif
