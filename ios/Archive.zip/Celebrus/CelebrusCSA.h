//
//  CelebrusCSA.h
//  CelebrusAppleCSA
//
//  Created by administrator on 09/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusCSA_h
#define CelebrusAppleCSA_CelebrusCSA_h

#import "CelebrusLogger.h"
#import "CelebrusCommunicationsMode.h"
#import "CelebrusOperationalMode.h"
#import "CelebrusControlType.h"
#import "CelebrusSelectedItem.h"
#import "CelebrusDataCaptureType.h"
#import "CelebrusPersonalizationCallback.h"
#import "CelebrusContentPlacement.h"
#import "CelebrusFormValue.h"
#import "CelebrusDataPrivacy.h"
#import "CelebrusPostalAddress.h"
#import "CelebrusConsentApi.h"

/**
 * The Celebrus CSA (Client-Side Adapter), surfacing a data collection
 * API for an iOS App. <br>
 * <br>
 * <strong>Lifecycle</strong><br>
 * The CSA is started using the
 * {@link #startWithCsaName:collectionUrl:isLocationCollectionEnabled:isUniqueVisitorTrackingEnabled:appName:}
 * method. It uses a background thread in which to perform all communications
 * asynchronously to the app being instrumented. This background thread
 * automatically shutdowns if the device goes offline. A
 * change in activity or online status will re-awaken the CSA. The CSA can be
 * stopped using the {@link CelebrusCSA#stop: (BOOL)} method which provides the ability
 * to wait for the CSA to shutdown by passing <code>true</code>. Although useful
 * in a test environment it is expected in a production environment that the CSA
 * is stopped passing in <code>false</code>. <br>
 * <br>
 * <strong>Timeouts</strong><br>
 * The CSA has default timeouts for an app session, these being 30 minutes for a
 * period of inactivity, and 3 hours for a maximum session duration. Both of
 * these can be modified using the
 * {@link CelebrusCSA#setMaxSessionDurationMillis: (long)} and
 * {@link CelebrusCSA#setIdleSessionExpiryDurationMillis: (long)}. <br>
 * <br>
 * <strong>Instrumentation</strong><br>
 * The <code>CSA</code> has no visible instance, with all access through
 * static methods. To start the CSA invoke
 * {@link #startWithCsaName:collectionUrl:isLocationCollectionEnabled:isUniqueVisitorTrackingEnabled:appName:}
 * can be done in the <code>FinishedLaunching</code> of the app's delegate. <br>
 *
 * <strong>Utilities</strong><br>
 * {@link CelebrusUtils#identifierForView: (UIView *)} provides a mechanism to
 * retrieve the view's associated resource name, which may be suitable to use as
 * the identifier within events.<br>
 * {@link CelebrusFormValuesBuilder} class exists to help in the formation of a form
 * event. <br>
 * <br>
 * <strong>Thread safety and exception handling</strong><br>
 * The CSA is thread-safe, meaning that it can be invoked by any thread within
 * the app with the implementation performing any synchronization itself. <br>
 * The CSA catches all {@link NSException} derived exceptions, preventing leakage
 * into the app. Any such exceptions are reported via the set logger, or simply
 * ignored if no logger has been provided. <br>
 * <br>
 * <strong>Logging</strong> <br>
 * The CSA comes with logging functionality, providing a base class
 * {@link CelebrusLogger} which implements all logging method with an empty
 * implementation. This can be extended and set on the CSA using the
 * {@link CelebrusCSA#setLogger: (CelebrusLogger *)} method. The implementation of the logger
 * writes to {@link NSLog}. The logger comes complete with log levels, with the default set to
 * {@link CelebrusLogLevel#warning}.
 * The {@link CelebrusLogger} implementation can be overriden
 * as required and set using the code as follows:
 *
 * <pre>
 * <code>
 *   CSA.setLogger(new LogCatLogger());
 * </code>
 * </pre>
 *
 * The logger can be changed at any time.<br>
 * <br>
 * <strong>Testing</strong> Testing the integration without sending data to a
 * collection server can be achieved simply by setting the SDK into dry-run
 * mode. This is achieved by setting the {@link CelebrusOperationalMode} parameters to
 * the
 * {@link #startWithCommunicationsMode:operationalMode:csaName:collectionUrl:isLocationCollectionEnabled:isUniqueVisitorTrackingEnabled:appName}
 * method to {@link CelebrusOperationalMode#DRY_RUN}.
 *
 * With a logger installed API calls and communication transmission requests
 * (although not sent) will be accessible. Note that the communication requests
 * are logged via the {@link CelebrusLogger#logConfigurationSent: (NSString *)} and
 * {@link CelebrusLogger#logDataSent: (NSString*)} methods. These provide the payload which
 * would be transmitted, though doesn't include HTTP header or response sizes.
 */
@interface CelebrusCSA : NSObject

@property (readonly, strong) NSString *loadBalancerId;
@property (readonly, strong) NSString *collectionUrl;
@property (readonly, strong) CelebrusCommunicationsMode *communicationsMode;
@property (readonly, strong) NSString *csaName;

-(CelebrusOperationalMode *) operationalMode;

/**
 * @return <code>true</code> if the CSA has been started and the event queue
 *         is actively running, <code>false</code> otherwise
 */
+(BOOL) isRunning;

/**
 * @param communicationsMode
 *            the transmission mode to be used batched automatically,
 *            manually, real-time etc
 * @param operationalMode
 *            when set to {@link CelebrusOperationalMode#DRY_RUN} no communications with the data
 *            server server are made permitting localised testing; when set to
 *            {@link CelebrusOperationalMode#LIVE} data is transmitted to the data collection server.
 *
 * @param csaName
 *            the CSA Name value assigned within the Data Collection Server
 * @param collectionUrl
 *            the external address by which the Data Collection Server can
 *            be accessed
 * @param isLocationCollectionEnabled
 *            <code>true</code> indicates that the geo-location of the
 *            device is to be collected.
 * @param isUniqueVisitorTrackingEnabled
 *            <code>true</code> indicates that a persistent identifier is to
 *            be placed onto the device to recognise multiple uses of the
 *            application as being from the same device
 *
 * @param appName
 *            the name identifier to be assigned for the app in any outgoing
 *            event data.
 */
+(void) startWithCommunicationsMode: (CelebrusCommunicationsMode *) communicationsMode
                    operationalMode: (CelebrusOperationalMode *) operationalMode
                            csaName: (NSString *) csaName
                      collectionUrl: (NSString *) collectionUrl
        isLocationCollectionEnabled: (BOOL) isLocationCollectionEnabled
     isUniqueVisitorTrackingEnabled: (BOOL) isUniqueVisitorTrackingEnabled
                            appName: (NSString *) appName;

/**
 * Starts the data collection with mode defaulted to
 * {@link CelebrusCommunications#REAL_TIME} in live mode.
 *
 * @param csaName
 *            the CSA Name value assigned within the Data Collection Server
 * @param collectionUrl
 *            the external address by which the Data Collection Server can
 *            be accessed
 * @param isLocationCollectionEnabled
 *            <code>true</code> indicates that the geo-location of the
 *            device is to be collected. If enabled the app's manifest must
 *            include <code>android.permission.ACCESS_FINE_LOCATION</code>
 *            otherwise the CSA will be unable to access the appropriate
 *            location services.
 * @param isUniqueVisitorTrackingEnabled
 *            <code>true</code> indicates that a persistent identifier is to
 *            be placed onto the device to recognise multiple uses of the
 *            application as being from the same device
 * @param appName
 *            the name of the app being instrumented. This name must match the
 *            licensing within the Celebrus data collection server
 *
 * @throws SecurityException
 *             if the appropriate INTERNET and ACCESS_NETWORK_STATE
 *             permissions have not been included in the AndroidManifest.xml
 */
+(void) startWithCsaName: (NSString *) csaName
           collectionUrl: (NSString *) collectionUrl
isLocationCollectionEnabled: (BOOL) isLocationCollectionEnabled
isUniqueVisitorTrackingEnabled: (BOOL) isUniqueVisitorTrackingEnabled
                 appName: (NSString *) appName;

+(long long) batchedFrequencyDurationMillis;

+(void) setBatchedFrequencyDurationMillis: (long long) milliseconds;

/**
 * @param maxQueueSize
 *
 * @throws IllegalArgumentException
 *             is maxQueueSize is less than 50
 */
+(void) setMaxEventQueueSize: (int) maxQueueSize;
+(int) maxEventQueueSize;

/**
 * Sets the max idle duration for the CSA specifies how many milliseconds
 * without any user activity can pass before the CSA should terminate the
 * session and create a new one. Defaults to 30 minutes.
 *
 * @param durationMillis
 */
+(void) setIdleSessionExpiryDurationMillis: (long long) durationMillis;

+(long long) idleSessionExpiryDurationMillis;

/**
 * Sets the max length of a session in milliseconds before the CSA should
 * terminate the session and create a new one. Defaults to 3 hours
 */
+(void) setMaxSessionDurationMillis: (long long) durationMillis;
+(long long) maxSessionDurationMillis;
+(void) sendEventsNow;

/**
 * @param maxBatchSizeInBytes the largest batch of data that the CSA is permitted to transmit in one batch
 *
 * @throws IllegalArgumentException
 *             if maxEventBatchSizeInBytes is less than 50KB
 */
+(void) setMaxEventBatchSizeInBytes: (int) maxBatchSizeInBytes;

+(int) maxEventBatchSizeInBytes;

+(CelebrusLogger *) logger;
+(void) setLogger: (CelebrusLogger *) logger;

/**
 * @param isWaitRequired
 *            if <code>true</code> the invocation will not return until the
 *            CSA has stopped completely, otherwise the CSA will be flagged
 *            to stop and will do so asynchronously to the caller. Waiting
 *            for the CSA to stop is useful in a unit test environment for
 *            example.
 */
+(void) stop: (BOOL) isWaitRequired;

+(void) resetDefaults;

+(void) clearDataTransmissionPermissionWindow;

/**
 * @return <code>true</code> if data is allowed to be sent,
 *         <code>false</code> otherwise
 */
-(BOOL) isWithinDataTransmissionPermissionWindow;

/**
 * @return <code>nil</code> if there is no current name
 */
+(NSString*) currentCsaName;

/**
 * @return <code>-1</code> if there is no current session
 */
+(long long) currentSessionNumber;

/**
 * @return <code>nil</code> if there is no current session
 */
+(NSString *) currentSessionKey;

+(NSUInteger) currentEventsInQueue;

/**
 * @return <code>-1</code> if there is no current session
 */
+(long long) currentCSANumber;

+(void) waitForIdle;

+(bool) isLoggingEnabled;
/**
 * @param contentName
 *            Defines a name for these offer locations. More than one
 *            ContentLoading events can be generated for the same page. For
 *            example, you may have a ContentLoading event which has the
 *            name static and is used to fill in the page with offers when
 *            it loads. Similarly, you may also have a separate
 *            ContentLoading event which has the name dynamic and is used to
 *            fill in an additional offer location if the user interacts
 *            with a page in a certain way (for example, by clicking on a
 *            check box, filling in a form field, or moving a slider
 *            control).
 * @param callback
 *            handler to invoke if a {@link ContentAction} is received for
 *            one of the specified placements. This callback is held with a
 *            {@link WeakReference} only by the {@link AndroidCSA} to avoid
 *            memory leaks. The App must therefore maintain a strong
 *            reference to this callback until it is no longer required.
 * @param isEnabled
 *            Whether the offers are enabled. If this attribute is not set,
 *            then the offers defined by this event are enabled.
 * @param contentHints
 *            Optional hints which guide the selection of applicable offers.
 *            This field can be used to store additional information in the
 *            session context. The rule which controls when the trigger will
 *            run can be configured to only fire depending on this value.
 * @param contentInteractionPoint
 *            Each <code{@link ContentPlacement} may include an interaction
 *            point designation, if it doesnt a default is used. In the
 *            case of RTIM, the trigger makes one request to RTIM for each
 *            interaction point. The returned messages are matched in order
 *            against the list of locations for the interaction point.
 * @param contentLanguage
 *            Optional language which guide to select the offers for specific
 *            language
 * @param placements
 *            Specifies where the offers should be presented. This
 *            information is
 */
+(void) contentLoadingWithContentName: (NSString *) contentName
                             callback: (id<CelebrusPersonalizationCallback>) callback
                            isEnabled: (bool) isEnabled
                         contentHints: (NSString*) contentHints
                     interactionPoint: (NSString*) contentInteractionPoint
                      contentLanguage: (NSString*) contentLanguage
                           placements: (NSArray<CelebrusContentPlacement*>*) placements;

+(void) unregisterPersonalizationCallback: (id<CelebrusPersonalizationCallback>) callback;

+(void)addDefaultContentLoadingCallback: (id <CelebrusPersonalizationCallback>) callback;

+(void) removeDefaultContentLoadingCallback;

+(void) contentActionedWithRuleUUID: (NSString*) executionRuleUUID
                         actionUUID: (NSString*) executionActionUUID
                        contentUUID: (NSString*) executionContentUUID
                  contentParameters: (NSString*) contentParameters;

+(void) contentClickedWithContentName: (NSString *) contentName
                            contentId: (NSString *) contentId
                                value: (NSString *) value
                             formName: (NSString *) formName
                               formId: (NSString *) formId
                             ruleUUID: (NSString *) executionRuleUUID
                           actionUUID: (NSString *) executionActionUUID
                          contentUUID: (NSString *) executionContentUUID
                     contentParameters: (NSString *) contentParameters;

/**
 * Defaults privacy to CelebrusDataPrivacy.mayContainPersonalData, indicating that the
 * JSON data is not anonymous and may contain personally identifiable
 * information (PII).
 */
+(void) sendJsonData: (NSDictionary *) jsonData;

/**
 * Requests to send JSON data. If the data is anonymous then it will be
 * captured even if the user consent is set to partially opted out
 * (anonymous). If data is not anonymous and the user consent is set to
 * partially opted out (anonymous) the data will not be discarded.
 *
 * @param dataPrivacy
 *            indicates whether the data may contain personally identifiable
 *            information (PII) or not.
 */
+(void) sendJsonData: (NSDictionary *) jsonData
             privacy: (CelebrusDataPrivacy *) privacy;

+(void) sendNavigate: (NSString *) sectionName;

+(void) sendNavigateForViewController: (UIViewController *) view;

+(void) sendButtonClickEvent: (NSString *) controlName
                        ctID: (NSString *) controlID
                       ctVal: (NSString *) controlValue
                  ctFormName: (NSString *) formName
                    ctFormID: (NSString *) formID;

+(void) sendBasketAdd: (NSString *) productID
           addedValue: (NSString *) value
        addedCurrency: (NSString *) currency
          displayName: (NSString *) displayName;

+(void) sendBasketAdd: (NSString *) productID
           addedValue: (NSString *) value
        addedCurrency: (NSString *) currency
          displayName: (NSString *) displayName
            skuNumber: (NSString *) skuNum
        addedQuantity: (NSString *) quantity
         valuePerItem: (BOOL) valPerItem;

+(void) sendWishlistAdd: (NSString *) productID
           addedValue: (NSString *) value
        addedCurrency: (NSString *) currency
          displayName: (NSString *) displayName
            skuNumber: (NSString *) skuNum
        addedQuantity: (NSString *) quantity
         valuePerItem: (BOOL) valPerItem;

+(void) sendBasketAddFailure: (NSString *) productID
              failureMessage: (NSString *) message;

+(void) sendBasketAmend: (NSString *) productID
            newQuantity: (NSString *) quantity;

+(void) sendBasketRemove:(NSString *) productID;

+(void) sendBasketClear:(NSString *) reason;

+(void) sendWishlistRemove:(NSString *) productID;

+(void) sendBasketTotal: (NSString *) totalValue
         basketCurrency: (NSString *) currency;

+(void) sendProductInBasket: (NSString *) productID
            displayName: (NSString *) displayName
                  group: (NSString *) group
          addedCurrency: (NSString *) currency
               quantity: (NSString *) quantity
              skuNumber: (NSString *) skuNum
             addedValue: (NSString *) value
        availabilityMsg: (NSString *) availabilityMsg
            shippingMsg: (NSString *) shippingMsg
              savingMsg: (NSString *) savingMsg;

+(void) sendProductInWishlist: (NSString *) productID
                displayName: (NSString *) displayName
                      group: (NSString *) group
              addedCurrency: (NSString *) currency
                   quantity: (NSString *) quantity
                  skuNumber: (NSString *) skuNum
                 addedValue: (NSString *) value;

+(void) sendProductView: (NSString *) productID
            displayName: (NSString *) displayName
                  group: (NSString *) group
          addedCurrency: (NSString *) currency
               quantity: (NSString *) quantity
              skuNumber: (NSString *) skuNum
             addedValue: (NSString *) value
        availabilityMsg: (NSString *) availabilityMsg
            shippingMsg: (NSString *) shippingMsg
              savingMsg: (NSString *) savingMsg;

+(void) sendBasketCheckout: (NSString *) basketValue
            basketCurrency: (NSString *) currency
          basketIdentifier: (NSString *) basketId
           shippingCostVal: (NSString *) shippingCost
                    taxVal: (NSString *) tax
           deliveryTypeVal: (NSString *) deliveryType
            paymentTypeVal: (NSString *) paymentType;

+(void) sendBasketView: (NSString *) basketValue
        basketCurrency: (NSString *) currency
      basketIdentifier: (NSString *) basketId
       shippingCostVal: (NSString *) shippingCost
                taxVal: (NSString *) tax
       deliveryTypeVal: (NSString *) deliveryType
        paymentTypeVal: (NSString *) paymentType
       shippingAddress: (CelebrusPostalAddress*) shippingAddress
        billingAddress: (CelebrusPostalAddress*) billingAddress;

+(void) sendBasketCheckout: (NSString *) basketValue
            basketCurrency: (NSString *) currency
          basketIdentifier: (NSString *) basketId
           shippingCostVal: (NSString *) shippingCost
                    taxVal: (NSString *) tax
           deliveryTypeVal: (NSString *) deliveryType
            paymentTypeVal: (NSString *) paymentType
           shippingAddress: (CelebrusPostalAddress*) shippingAddress
            billingAddress: (CelebrusPostalAddress*) billingAddress;


+(void) sendPurchase: (NSString *) orderNumber
          totalValue: (NSString *) totalValue
      basketCurrency: (NSString *) basketCurrency;

+(void)sendFormValues: (NSArray<CelebrusFormValue*> *) formValues
             formName: (NSString *) formName
               formID: (NSString *) formID;

+(void) sendListItemSelect: (NSString *) controlName
                      ctID: (NSString *) controlID
                     ctVal: (NSString *) controlValue
                ctFormName: (NSString *) formName
                  ctFormID: (NSString *) formID
             selectedIndex: (int) selectedIndex
             selectedValue: (NSString *) selectedValue;

+(void) sendListItemSelect: (NSString *) controlName
                      ctID: (NSString *) controlID
                     ctVal: (NSString *) controlValue
                ctFormName: (NSString *) formName
                  ctFormID: (NSString *) formID
             selectedIndex: (int) selectedIndex;

+(void) sendListItemSelect: (NSString *) controlName
                      ctID: (NSString *) controlID
                     ctVal: (NSString *) controlValue
                ctFormName: (NSString *) formName
                  ctFormID: (NSString *) formID
             selectedItems: (NSArray<CelebrusSelectedItem *> *) selectedItemsArray;

+(void) sendCheckBoxSelect: (NSString *) controlName
                      ctID: (NSString *) controlID
                     ctVal: (NSString *) controlValue
                ctFormName: (NSString *) formName
                  ctFormID: (NSString *) formID
                   checked: (BOOL) isChecked;

+(void) sendRadioSelect: (NSString *) controlName
                   ctID: (NSString *) controlID
                  ctVal: (NSString *) controlValue
             ctFormName: (NSString *) formName
               ctFormID: (NSString *) formID
                checked: (BOOL) isChecked;

+(void) sendTextChangeEvent: (NSString *) controlName
                       ctID: (NSString *) controlID
                      ctVal: (NSString *) controlValue
                 ctFormName: (NSString *) formName
                   ctFormID: (NSString *) formID
                     ctType: (CelebrusControlType *) controlType;

+(void) sendNavigatorInfo;

+(void) sendClickEvent: (UIView *) view;

+(void) sendClickEvent: (NSString *) controlName
                  ctID: (NSString *) controlID
                 ctVal: (NSString *) controlValue
            ctFormName: (NSString *) formName
              ctFormID: (NSString *) formID
                ctType: (CelebrusControlType *) controlType;

+(void) shareDeviceIdWithWebViewDomains:(NSString *) domains;

+(NSString *) uniqueVisitorTrackingCookie;

+(void) showSessionIdentificationAlert;

+(void) sendPositionWithLatitude: (double) latitude
                    andLongitude: (double) longitude;

/**
 * @param tags a comma separated list of app-defined fields which give context to the current
 * location. These fields are context related to the visitor's mode of transport, or current
 * location. For example: "ByCar", "OnFoot", "OneMileOrLessToBranch",
 * "CloseToSoftDrinksAisle", and "NearStoreEntrance".
 */
+(void) sendPositionWithLatitude: (double) latitude
                    andLongitude: (double) longitude
                            tags: (NSString*) tags;

+(CelebrusConsentApi *) consentApi;


@end

#endif
