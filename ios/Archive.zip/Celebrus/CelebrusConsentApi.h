//
//  CelebrusConsentApi.h
//  CelebrusV8
//
//  Created by Achu on 01/08/2017.
//  Copyright © 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusConsentApi_h
#define CelebrusConsentApi_h

#import "CelebrusConsentType.h"

@interface CelebrusConsentApi : NSObject

-(void)optIn;

-(void)optOut;

-(void)anonymous;

-(void)clear;

-(CelebrusConsentType *) consent;

-(void)setConsent: (CelebrusConsentType *) consent;

@end


#endif /* CelebrusConsentApi_h */
