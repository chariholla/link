//
//  CelebrusContentAction.h
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusContentAction_h
#define CelebrusContentAction_h

#import "CelebrusAction.h"
#import "CelebrusContentType.h"
#import "CelebrusObjectIdentificationType.h"
#import "CelebrusContentActionMethod.h"
#import "CelebrusContentType.h"
#import "CelebrusAttribute.h"

@interface CelebrusContentAction : CelebrusAction
@property (readonly, strong) NSString* sessionKey;
@property (readonly) long long csaNumber;
@property (readonly, strong) CelebrusObjectIdentificationType* targetType;
@property (readonly, strong) NSString* target;
@property (readonly, strong) NSString* targetClickUrl;
@property (readonly, strong) CelebrusContentActionMethod* actionType;
@property (readonly, strong) CelebrusContentType* contentType;
@property (readonly, strong) NSArray<CelebrusAttribute*>* attributesArray;

/**
 * UUID of a specific rule present within the system. This should be
 * provided when calling into
 * {@link AndroidCSA#contentClicked(String, String, String, String)} or
 * {@link AndroidCSA#contentActioned(String, String, String, String)}
 */
@property (readonly, strong) NSString* executionRuleUUID;

/**
 * Additional information the provider of the content has tagged with the
 * content. This should be provided when calling into
 * {@link AndroidCSA#contentClicked(String, String, String, String)} or
 * {@link AndroidCSA#contentActioned(String, String, String, String)}
 */
@property (readonly, strong) NSString* contentParameters;

/**
 * UUID of a specific action present within the system. This should be
 * provided when calling into
 * {@link AndroidCSA#contentClicked(String, String, String, String)} or
 * {@link AndroidCSA#contentActioned(String, String, String, String)}
 */
@property (readonly,strong) NSString* executionActionUUID;

/**
 * UUID of a specific piece of content, served up as a result of rule
 * processing. This attribute is only set for content provided by the
 * Real-Time Server content library. Data streams and third party
 * application triggers do not populate this attribute. This should be
 * provided when calling into
 * {@link AndroidCSA#contentClicked(String, String, String, String)} or
 * {@link AndroidCSA#contentActioned(String, String, String, String)}
 */
@property (readonly,strong) NSString* executionContentUUID;

@property (readonly,strong) NSString* content;

-(id) initWithSessionKey: (NSString*) key
               csaNumber: (long long) csaNumber
                ruleUUID: (NSString *) ruleUUID
              actionUUID: (NSString *) actionUUID
             contentUUID: (NSString *) contentUUID
       contentParameters: (NSString *) contentParameters
              targetType: (CelebrusObjectIdentificationType *) targetType
                  target: (NSString *) target
              actionType: (CelebrusContentActionMethod *) actionType
             contentType: (CelebrusContentType *) contentType
                 content: (NSString *) content
          targetClickUrl: (NSString *) targetClickUrl
         attributesArray: (NSArray<CelebrusAttribute*>*) attributesArray;

-(NSDictionary*) toJson;

/**
 * @return the personalised content.
 *         The content has its Celebrus transport wrapper removed so only the plain context is returned.
 */
-(NSString*) content;

+(CelebrusContentAction*) contentActionFromJson: (NSDictionary*) json;

@end

#endif /* CelebrusContentAction_h */
