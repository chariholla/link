//
//  CelebrusSelectedItem.h
//  CelebrusV8
//
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CelebrusSelectedItem : NSObject

@property (readonly, strong) NSString *selectedValue;
@property (readonly) int selectedIndex;

-(id) initWithValue: (NSString *) value
        selectedIndex: (int) index;

@end
