//
//  CelebrusPostalAddress.h
//  CelebrusV8
//
//  Created by administrator on 05/08/2017.
//  Copyright © 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusPostalAddress_h
#define CelebrusPostalAddress_h

@interface CelebrusPostalAddress : NSObject

@property (readonly, strong) NSString *company;
@property (readonly, strong) NSString *addressLine1;
@property (readonly, strong) NSString *addressLine2;
@property (readonly, strong) NSString *addressLine3;
@property (readonly, strong) NSString *addressLine4;
@property (readonly, strong) NSString *city;
@property (readonly, strong) NSString *region;
@property (readonly, strong) NSString *postCode;
@property (readonly, strong) NSString *country;

-(id) initWithCompany: (NSString *) company
         addressLine1: (NSString *) addressLine1
         addressLine2: (NSString *) addressLine2
         addressLine3: (NSString *) addressLine3
         addressLine4: (NSString *) addressLine4
                 city: (NSString *) city
               region: (NSString *) region
              country: (NSString *) country;

-(NSString*) toValue: (NSString*) addressType;

@end

#endif /* CelebrusPostalAddress_h */
