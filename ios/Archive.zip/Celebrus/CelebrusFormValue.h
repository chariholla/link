//
//  CelebrusFormValue.h
//  CelebrusAppleCSA
//
//  Created by administrator on 10/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusFormValue_h
#define CelebrusAppleCSA_CelebrusFormValue_h

#import "CelebrusControlType.h"

@interface CelebrusFormValue : NSObject

@property (readonly, strong) NSString *name;
@property (readonly, strong) NSString *identifier;
@property (readonly, strong) NSString *value;
@property (readonly, strong) CelebrusControlType *type;

-(id) initWithName: (NSString *) name
        identifier: (NSString *) identifier
             value: (NSString *) value
       controlType: (CelebrusControlType *) type;

@end

#endif
