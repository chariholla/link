//
//  CelebrusContentPlacement.h
//  CelebrusV8
//
//  Created by administrator on 14/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusContentPlacement_h
#define CelebrusContentPlacement_h

#import "CelebrusContentActionMethod.h"
#import "CelebrusObjectIdentificationType.h"

@interface CelebrusContentPlacement : NSObject

@property (strong, readonly) CelebrusContentActionMethod* action;
@property (strong, readonly) CelebrusObjectIdentificationType* targetType;
@property (strong, readonly) NSString* target;
@property (readonly) bool isRegEx;
@property (strong, readonly) NSString* interactionPoint;
@property (strong, readonly) NSString* format;

/**
 * @param action
 *            Specifies how the content should be inserted into the page.
 * @param targetType
 *            Identifies the type of object for this content insertion. The
 *            target type is used in conjunction with the target property.
 * @param target
 *            If the targetType is {@link ContentActionMethod#TOP_OF_PAGE}
 *            or {@link ContentActionMethod#BOTTOM_OF_PAGE}. The target
 *            property identifies the object to locate when content is
 *            either being replaced or inserted. The type of the objects is
 *            specified by the targetType property. The target must be
 *            unique otherwise all matching elements may be replaced.
 * @param isRegEx
 *            True if the target property should be interpreted as a
 *            JavaScript regular expression. This is a powerful feature
 *            which allows multiple objects on a page to be identified.
 * @param interactionPoint
 *            Specifies the RTIM interaction point or null if not
 *            applicable.
 * @param format
 *            An optional free text string which describes the presentation
 *            format for the offer. The permissible values for this field
 *            needs to be agreed with the content management system. Common
 *            examples might be banner, header or footer. It is recommended
 *            not to include specific dimensions in this field such as
 *            320x240 (pixels) because it creates a system which is hard to
 *            evolve over time. Instead the field should contain meaningful
 *            names which the content management system can translate into
 *            an appropriate resolution.
 */
-(id) initWithAction: (CelebrusContentActionMethod*) action
          targetType: (CelebrusObjectIdentificationType*) targetType
              target: (NSString*) target
             isRegEx: (bool) isRegEx
    interactionPoint: (NSString*) interactionPoint
              format: (NSString*) format;

-(NSDictionary*) toJson;

+(NSMutableArray<CelebrusContentPlacement*> *) createReplaceId: (NSArray*) contentId;

@end

#endif /* CelebrusContentPlacement_h */
