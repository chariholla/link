//
//  OperationalMode.h
//  CelebrusAppleCSA
//
//  Created by administrator on 09/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_OperationalMode_h
#define CelebrusAppleCSA_OperationalMode_h

@interface CelebrusOperationalMode : NSObject

+(CelebrusOperationalMode *) live;
+(CelebrusOperationalMode *) dryRun;

-(BOOL) isDryRun;
-(BOOL) isLive;

@end

#endif
