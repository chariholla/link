//
//  CelebrusContentType.h
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusContentType_h
#define CelebrusContentType_h

@interface CelebrusContentType : NSObject

@property (strong, readonly) NSString* name;

+(CelebrusContentType *) image;
+(CelebrusContentType *) text;
+(CelebrusContentType *) javaScript;
+(CelebrusContentType *) html;
+(CelebrusContentType *) xhtml;
+(CelebrusContentType *) redirect;

+(CelebrusContentType*) fromString: (NSString*) value;

@end

#endif /* CelebrusContentType_h */
