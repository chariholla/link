//
//  CelebrusAutoInstrument.h
//  CelebrusAppleCSA
//
//  Created by administrator on 17/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusAutoInstrument_h
#define CelebrusAppleCSA_CelebrusAutoInstrument_h

#import "CelebrusInstrumentationOption.h"

@interface CelebrusAutoInstrument : NSObject

+(void) instrumentUiApplication: (UIApplication *) application;

+(void) instrumentUiApplication: (UIApplication *)application
                        options: (NSArray<CelebrusInstrumentationOption*> *)options;

+(void) instrumentUiView: (UIView *) view;

+(void) instrumentUiView: (UIView *) view
                 options: (NSArray<CelebrusInstrumentationOption*> *) options;

+(void) instrumentUiTableView: (UITableView *) tableView;

@end

#endif
