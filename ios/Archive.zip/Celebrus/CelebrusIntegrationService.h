//
//  CelebrusIntegrationService.h
//  CelebrusAppleCSA
//
//  Created by administrator on 11/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusIntegrationService_h
#define CelebrusAppleCSA_CelebrusIntegrationService_h

#import "CelebrusControlType.h"
#import "CelebrusSelectedItem.h"

/**
 * A service that extracts identifiers, names and values from a {@link UIView}.
 * These implementations come into effect if the automatic data extraction API
 * calls used instead such as {@link CelebrusCSA#sendClickEvent: (UIView *)}. In
 * constrast the explicit APIs require these values to be determined manually
 * such as
 * {@link CelebrusCSA#sendClickEvent::ctID:ctVal:value:ctFormName:ctFormID}
 * . Although the manual approach does give more flexibility, the automated
 * extraction ensures consistency. <br>
 * <br>
 * {@link CelebrusUtils#setIntegrationService: (CelebrusIntegrationService *)} and
 * {@link CelebrusUtils#integrationService} for its use.<br>
 *<br>
 * The implementations uses the accessibilityIdentifier for an element's identifier, and the accessibilityLabel for the name.
 * These are as used within UI automation testing available to iOS developers, as detailed at
 * https://developer.apple.com/library/ios/documentation/DeveloperTools/Conceptual/InstrumentsUserGuide/UsingtheAutomationInstrument/UsingtheAutomationInstrument.html.
 */
@interface CelebrusIntegrationService : NSObject

-(NSString *) name: (UIView *) view;

-(NSString *) identifier: (UIView *) view;

-(NSString *) formName: (UIView *) view;

-(NSString *) formIdentifier: (UIView *) view;

/**
 * @return the value associated with the view or '***' if #isSensitiveData returns TRUE
 */
-(NSString *) value: (UIView *) view;

-(int) selectedIndex: (UIView *) view;

/**
 * @return TRUE if the view is a UITextField and its isSecureTextEntry is TRUE
 */
-(BOOL) isSensitiveData: (UIView *) view;

/**
 *  @return the appropriate {@link CelebrusControlType} for the view
 */
-(CelebrusControlType *) controlType: (UIView *) view;


-(NSString *) valueForTable:(UITableView *) tableView
             tableIndexPath:(NSIndexPath *) indexPath;

-(int) selectedIndexForTableView:(UITableView *) tableView
                    forIndexPath:(NSIndexPath *) path;

-(NSArray<CelebrusSelectedItem *> *) selectedItemsForTableAfterTap:(UITableView *) tableView
                                                        tappedCellIndexPath:(NSIndexPath *) tappedCellPath;

-(void) shareDeviceIdWithWebViewDomains: (NSArray *) domains
                                withUvt: (NSString *) uvt;

-(void) showSessionIdentificationAlert: (long long) currentSessionNumber
                        withSessionKey: (NSString *) currentSessionKey;

@end

#endif
