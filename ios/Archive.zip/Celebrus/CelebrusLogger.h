//
//  CelebrusNSLogLogger.h
//  CelebrusAppleCSA
//
//  Created by administrator on 10/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusNSLogLogger_h
#define CelebrusAppleCSA_CelebrusNSLogLogger_h

#import <UIKit/UIKit.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import "CelebrusLogLevel.h"

@interface CelebrusLogger : NSObject

+(BOOL) isEnabled: (CelebrusLogLevel *) level;
+(void) setLogLevel: (CelebrusLogLevel *) level;
+(CelebrusLogLevel *) logLevel;

-(void) logUnlicensedEventDropped;

-(void) logApiCall: (NSString *) methodName;

-(void) logEventQueued;

-(void) logQueueAtCapacityEventDropped;

-(void) logNotInitialized: (NSString *) methodName;

-(void) logException: (NSException *) e;

-(void) logError: (NSError *) e;

-(void) logJSContextError: (JSValue *) e;

-(void) logMessage: (NSString *) message
         withLevel: (CelebrusLogLevel *) level;

-(void) logEventFiltered: (NSString*) eventType;

/**
 * details the request as being sent to the data collection server
 */
-(void) logDataSent: (NSString *) request;

-(void) logConfigurationSent: (NSString *) request;

-(void) logInstrumenting: (UIView *) view;

-(void) logInstrumenting: (NSString *) message
               withLevel: (CelebrusLogLevel *) level;

-(void) logUnlicensedApp: (NSString *) appName;

-(void) logCollectionDisabled: (NSString *) controlType;

+(CelebrusLogLevel *) logLevelForLogApiCall;

@end
#endif
