//
//  CelebrusFormValuesBuilder.h
//  CelebrusV8
//
//  Created by administrator on 09/06/2015.
//  Copyright (c) 2015 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusV8_CelebrusFormValuesBuilder_h
#define CelebrusV8_CelebrusFormValuesBuilder_h
#import "CelebrusFormValue.h"

/**
 * Builder for creating multiple {@link CelebrusFormValue} suitable for use within calls
 * to {@link CelebrusCSA#sendFormValues: (NSArray *) formName: (NSString *) formID: (NSString *)}.
 */
@interface CelebrusFormValuesBuilder : NSObject
-(CelebrusFormValuesBuilder *) addValuesForViews: (UIView *) view, ...;
-(CelebrusFormValuesBuilder *) addValueForView: (UIView *) view;
-(CelebrusFormValuesBuilder *) addValue: (CelebrusFormValue *) formValue;
-(NSArray *) values;
-(void) clear;
@end

#endif
