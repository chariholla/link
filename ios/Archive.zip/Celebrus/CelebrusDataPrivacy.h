//
//  CelebrusDataPrivacy.h
//  CelebrusV8
//
//  Created by administrator on 04/08/2017.
//  Copyright © 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusDataPrivacy_h
#define CelebrusDataPrivacy_h

@interface CelebrusDataPrivacy : NSObject

+(CelebrusDataPrivacy *) mayContainPersonalData;
+(CelebrusDataPrivacy *) anonymousDataOnly;

-(BOOL) isPersonalData;


@end

#endif /* CelebrusDataPrivacy_h */
