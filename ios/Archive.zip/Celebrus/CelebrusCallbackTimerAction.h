//
//  CelebrusTimerAction.h
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusTimerAction_h
#define CelebrusTimerAction_h

#import "CelebrusAction.h"

@interface CelebrusCallbackTimerAction : CelebrusAction

@property (readonly) long long callbackTimestampMillis;
@property (readonly) long long csaNumber;

-(id) initWithCallbackTimestamp: (long long) callbackTimestampMillis
                      csaNumber: (long long) csaNumber;

+(CelebrusCallbackTimerAction*) callbackActionFromJson: (NSDictionary*) json;

@end

#endif /* CelebrusTimerAction_h */