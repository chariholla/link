//
//  CelebrusAbstractAction.m
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusAction_h
#define CelebrusAction_h

#import <Foundation/Foundation.h>

@interface CelebrusAction : NSObject

-(bool) isTimer;

+(NSArray<CelebrusAction*>*) fromJson: (NSDictionary*) json;

@end

#endif