//
//  CelebrusPersonalizationCallback.h
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusPersonalizationCallback_h
#define CelebrusPersonalizationCallback_h

#include "CelebrusContentAction.h"

@protocol CelebrusPersonalizationCallback <NSObject>

/**
 * Invoked on the UI thread.
 */
-(void) displayContent: (CelebrusContentAction*) contentAction;

@end

#endif /* CelebrusPersonalizationCallback_h */
