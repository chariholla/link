//
//  CelebrusInstrumentationOption.h
//  CelebrusV8
//
//  Created by administrator on 06/08/2017.
//  Copyright © 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusInstrumentationOption_h
#define CelebrusInstrumentationOption_h

@interface CelebrusInstrumentationOption : NSObject

+(CelebrusInstrumentationOption*) orientation;

@property (strong, readonly) NSString* name;

@end

#endif /* CelebrusInstrumentationOption_h */
