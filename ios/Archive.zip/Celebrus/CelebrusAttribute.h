//
//  CelebrusAttribute.h
//  CelebrusV8
//
//  Created by IS Solutions PLC on 24/01/2017.
//  Copyright © 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusAttribute_h
#define CelebrusAttribute_h

#import <Foundation/Foundation.h>

@interface CelebrusAttribute : NSObject

@property (readonly, strong) NSString* attributeType;
@property (readonly, strong) NSString* attributeValue;
@property (nonatomic, assign) BOOL attributeIsRegEx;

-(id)initWithAttributeType: (NSString *) attributeType
            attributeValue: (NSString*) attributeValue
          attributeIsRegEx: (BOOL) attributeIsRegEx;

-(CelebrusAttribute*)attributeType: (NSString*) attributeType
                    attributeValue: (NSString*) attributeValue
                  attributeIsRegEx: (BOOL) attributeIsRegEx;

@end

#endif /* CelebrusAttribute_h */
