//
//  ControlType.h
//  CelebrusV8
//
//  Created by administrator on 09/09/2015.
//  Copyright (c) 2015 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusV8_ControlType_h
#define CelebrusV8_ControlType_h



@interface CelebrusControlType : NSObject


+(CelebrusControlType *) button;
+(CelebrusControlType *) textarea;
+(CelebrusControlType *) text;
+(CelebrusControlType *) password;
+(CelebrusControlType *) radio;
+(CelebrusControlType *) checkbox;
+(CelebrusControlType *) submit;
+(CelebrusControlType *) reset;
+(CelebrusControlType *) image;
+(CelebrusControlType *) select;
+(CelebrusControlType *) file;

@property (readonly, strong) NSString *name;

-(bool) isUserInput;

@end

#endif