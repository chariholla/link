//
//  WebViewPersonalizationCallback.h
//  CelebrusV8
//
//  Created by administrator on 15/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusWebViewPersonalizationCallback_h
#define CelebrusWebViewPersonalizationCallback_h

#import <WebKit/WebKit.h>
#import "CelebrusPersonalizationCallback.h"
#import "CelebrusWebAppInterface.h"

@interface CelebrusWebViewPersonalizationCallback : NSObject<CelebrusPersonalizationCallback, CelebrusWebAppInterface>

-(id) initWithWebView: (UIWebView*) webView;

-(void) evaluateJavascript: (NSString*)javascript;

@end

#endif /* CelebrusWebViewPersonalizationCallback_h */
