//
//  CelebrusWebAppInterface.h
//  CelebrusV8
//
//  Created by administrator on 15/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusWebAppInterface_h
#define CelebrusWebAppInterface_h

#import <JavaScriptCore/JavaScriptCore.h>

@protocol CelebrusWebAppInterface <JSExport>

/** Callback from javascript to send content clicked on webview **/
JSExportAs(sendContentClicked, -(void)sendContentClicked: (NSString*) contentName
                                               contentId: (NSString*) contentId
                                                   value: (NSString*) value
                                                formName: (NSString*) formName
                                                  formId: (NSString*) formId
                                                  ruleID: (NSString*) ruleID
                                                actionID: (NSString*) actionID
                                               contentID: (NSString*) contentID
                                            customDataID: (NSString*) customDataID);

JSExportAs(sendContentActioned, -(void)sendContentActioned: (NSString*) currentRuleID
                                           currentActionID: (NSString*) currentActionID
                                          currentContentID: (NSString*) currentContentID
                                           currentCustomID: (NSString*) currentCustomID);

@end
#endif /* CelebrusWebAppInterface_h */
