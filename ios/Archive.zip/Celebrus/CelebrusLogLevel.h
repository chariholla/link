//
//  CelebrusNSLogLevel.h
//  CelebrusAppleCSA
//
//  Created by administrator on 10/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusNSLogLevel_h
#define CelebrusAppleCSA_CelebrusNSLogLevel_h

@interface CelebrusLogLevel : NSObject
{
    const CelebrusLogLevel *_OFF;
    const CelebrusLogLevel *_ERROR;
    const CelebrusLogLevel *_WARNING;
    const CelebrusLogLevel *_INFORMATION;
    const CelebrusLogLevel *_VERBOSE;
}

@property (readonly) unsigned level;
@property (readonly, strong) NSString *name;

+(CelebrusLogLevel *) off;
+(CelebrusLogLevel *) error;
+(CelebrusLogLevel *) warning;
+(CelebrusLogLevel *) information;
+(CelebrusLogLevel *) verbose;

@end

#endif

