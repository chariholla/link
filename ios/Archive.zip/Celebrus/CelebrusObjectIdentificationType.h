//
//  CelebrusObjectIdentificationType.h
//  CelebrusV8
//
//  Created by administrator on 14/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusObjectIdentificationType_h
#define CelebrusObjectIdentificationType_h

@interface CelebrusObjectIdentificationType : NSObject

@property (strong, readonly) NSString* name;

+(CelebrusObjectIdentificationType *) name;
+(CelebrusObjectIdentificationType *) identifier;
+(CelebrusObjectIdentificationType *) image;
+(CelebrusObjectIdentificationType *) clss;
+(CelebrusObjectIdentificationType *) anchor;
+(CelebrusObjectIdentificationType *) tagname;
+(CelebrusObjectIdentificationType *) formName;
+(CelebrusObjectIdentificationType *) formId;
+(CelebrusObjectIdentificationType *) type;

+(CelebrusObjectIdentificationType*) fromString: (NSString*) value;

@end


#endif /* CelebrusObjectIdentificationType_h */
