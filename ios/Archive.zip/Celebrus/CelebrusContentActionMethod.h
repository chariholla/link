//
//  CelebrusContentActionMethod.h
//  CelebrusV8
//
//  Created by administrator on 13/12/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusContentActionMethod_h
#define CelebrusContentActionMethod_h

@interface CelebrusContentActionMethod : NSObject

@property (readonly) int identifier;
@property (readonly) bool isPageLocation;
@property (readonly) NSString *name;

+(CelebrusContentActionMethod *) replace;
+(CelebrusContentActionMethod *) insertBefore;
+(CelebrusContentActionMethod *) insertAfter;
+(CelebrusContentActionMethod *) topOfPage;
+(CelebrusContentActionMethod *) bottomOfPage;

+(CelebrusContentActionMethod *) fromIdentifier: (int) value;

@end

#endif /* CelebrusContentActionMethod_h */
