
//
//  CelebrusCommunicationsMode.h
//  CelebrusAppleCSA
//
//  Created by administrator on 14/05/2015.
//  Copyright (c) 2015 Celebrus. All rights reserved.
//

#ifndef CelebrusAppleCSA_CelebrusCommunicationsMode_h
#define CelebrusAppleCSA_CelebrusCommunicationsMode_h

@interface CelebrusCommunicationsMode : NSObject

/**
 * Collection data will be queued but not transmitted until
 * {@link CelebrusCSA#sendEventsNow()} is invoked.
 */
+(CelebrusCommunicationsMode *) batchedManually;

/**
 * Collected data will be transmitted to the data collection servers in
 * batches, the frequency of which is defined by
 * {@link CelebrusCSA#batchedFrequencyDurationMillis()}
 */
+(CelebrusCommunicationsMode *) batchedPeriodically;

/**
 * Collected data will be transmitted to the data collection servers as soon
 * as possible.
 */
+(CelebrusCommunicationsMode *) realTime;

-(BOOL) isPeriodic;

-(BOOL) isRealTime;

@end

#endif
