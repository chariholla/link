//
//  CelebrusEventFiltering.h
//  CelebrusV8
//
//  Created by IS Solutions on 16/11/2016.
//  Copyright © 2016 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusEventFiltering_h
#define CelebrusEventFiltering_h

@interface CelebrusDataCaptureType : NSObject

@property (readonly) NSString * name;

+(CelebrusDataCaptureType *) manual;
+(CelebrusDataCaptureType *) automatic;

@end

#endif
