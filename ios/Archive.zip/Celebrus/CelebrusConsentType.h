//
//  CelebrusConsentType.h
//  CelebrusV8
//
//  Created by Achu on 26/04/2017.
//  Copyright (c) 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusConsentType_h
#define CelebrusConsentType_h

@interface CelebrusConsentType : NSObject

+(CelebrusConsentType *) optOut;
+(CelebrusConsentType *) optIn;
+(CelebrusConsentType *) anonymous;

+(CelebrusConsentType *) fromP3pCookieValue: (NSString *) p3pCookieValue
                               defaultValue: (CelebrusConsentType *) defaultValue;

@property (readonly, strong) NSString *p3pCookieValue;

@end

#endif