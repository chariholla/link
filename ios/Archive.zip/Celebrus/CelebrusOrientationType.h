//
//  CelebrusOrientationType.h
//  CelebrusV8
//
//  Created by Achu on 05/04/2017.
//  Copyright (c) 2017 Celebrus Technologies Ltd. All rights reserved.
//

#ifndef CelebrusV8_CelebrusOrientationType_h
#define CelebrusV8_CelebrusOrientationType_h



@interface CelebrusOrientationType : NSObject

+(CelebrusOrientationType *) portrait;
+(CelebrusOrientationType *) landscape;
+(CelebrusOrientationType *) faceUp;
+(CelebrusOrientationType *) faceDown;
+(CelebrusOrientationType *) upsideDown;


@property (readonly, strong) NSString *name;


@end

#endif